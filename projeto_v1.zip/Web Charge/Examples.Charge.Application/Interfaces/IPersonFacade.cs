﻿namespace Examples.Charge.Application.Interfaces
{
    public interface IPersonFacade
    {
    }
}