﻿namespace Examples.Charge.Application.Messages.Request
{
    public class PersonRequest
    {
        public string Nome { get; set; }
    }
}
